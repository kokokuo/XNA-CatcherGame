This is desktop version by using monogame 3.1 framework
and we stop developing this desktop when we discover monogame desktop project does not support touch mode
during Intel Innovation Contest 2013.

this version is still staying the dictionary added part of sync  
