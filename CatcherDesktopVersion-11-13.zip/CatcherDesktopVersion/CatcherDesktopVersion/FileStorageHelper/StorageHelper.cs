﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;


namespace CatcherDesktopVersion.FileStorageHelper
{
    public class StorageHelper
    {
        //序列化函式
        static public void SerializeBinary(string filename,GameRecordData record)
        {
        
            //建立資料流物件
            FileStream oFileStream = new FileStream("record.catcher", FileMode.Create );
            //建立二進位格式化物件
            BinaryFormatter myBinaryFormatter = new BinaryFormatter();
            Console.WriteLine("二進位格式序列化......");
            //將物件進行二進位格式序列化，並且將之儲存成檔案
            myBinaryFormatter.Serialize(oFileStream, record);
            oFileStream.Flush();
            oFileStream.Close();
            oFileStream.Dispose();
            Console.WriteLine("完成進位格式序列化......");
        }

        //反序列函式
        static public GameRecordData DeSerialize(string filename)
        {
            GameRecordData o = null;
            if(File.Exists(filename)){
                FileStream oFileStream = new FileStream(filename, FileMode.Open);
                BinaryFormatter myBinaryFormatter = new BinaryFormatter();
                Console.WriteLine("開始還原序列化物件......");
                //將檔案還原成原來的物件
                o = (GameRecordData)myBinaryFormatter.Deserialize(oFileStream);
            }
            return o;
        }
    }
}
