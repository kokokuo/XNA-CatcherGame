﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization; 
using CatcherDesktopVersion.GameObjects;

namespace CatcherDesktopVersion.FileStorageHelper
{
    
    [Serializable]
    public class GameRecordData
    {
        
        public int HistoryTopSavedNumber { get; set; }

        List<DropObjectsKeyEnum> caughtObjects;

        public List<DropObjectsKeyEnum> CaughtDropObjects { get; set; }

        public int CurrentSavePeopleNumber { get; set; }
    }
}
