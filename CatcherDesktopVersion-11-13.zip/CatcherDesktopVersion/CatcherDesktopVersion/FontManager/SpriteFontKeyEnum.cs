﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CatcherDesktopVersion.FontManager
{
    public enum SpriteFontKeyEnum
    {
        TOP_SCORE_FONT = 0,
        PLAY_SAVED_PEOPLE_FONT,
        PLAT_LOST_PEOPLE_FONT,
        GAME_VOER_CURRENT_SAVED_PEOPLE_FONT
    }
}
