﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CatcherDesktopVersion.GameStates
{
    public enum GameStateEnum{
        STATE_MENU = 0,
        STATE_PLAYGAME,      
        STATE_START_COMIC,
        STATE_GAME_OVER,
        TOTAL_STATE_NUMBER
    }
}
