﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Input.Touch;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using CatcherDesktopVersion.GameStates;
using CatcherDesktopVersion.GameObjects;
using CatcherDesktopVersion.FontManager;
using CatcherDesktopVersion.FileStorageHelper;
using CatcherDesktopVersion.TextureManager;
namespace CatcherDesktopVersion.GameStates.Dialog
{
    public class TopScoreDialog : GameDialog
    {
        SpriteFont topSavedPeopleNumberFont;
        GameRecordData readData;
        string topSavedPeoepleNumber;
        
        public TopScoreDialog(GameState pCurrentState)
            : base(pCurrentState) 
        { 
        }

        public override void BeginInit()
        {
            backgroundPos = new Vector2(0,0);
            closeButton = new Button(base.currentState, base.countId++, 0, 0);
            AddGameObject(closeButton);
            topSavedPeoepleNumber = "Not Saved";
            //讀取紀錄檔
            Readcored();
            

            base.isInit = true;
        }
        public override void LoadResource()
        {
            background = currentState.GetTexture2DList(TextureManager.TexturesKeyEnum.TOP_SCORE_DIALOG_BACK)[0];
            topSavedPeopleNumberFont = currentState.GetSpriteFontFromKeyByGameState(SpriteFontKeyEnum.TOP_SCORE_FONT);
            closeButton.LoadResource(TexturesKeyEnum.TOP_SCORE_CLOSE_BUTTON);
            base.LoadResource(); //載入CloseButton 圖片資源
            base.isLoadContent = true;
        }
        public override void Update()
        {
            //讀取紀錄檔
            Readcored();

            TouchCollection tc = base.currentState.GetCurrentFrameTouchCollection();
            bool isClickClose = false;
            if (tc.Count > 0){
                //所有當下的觸控點去判斷有無點到按鈕
                foreach (TouchLocation touchLocation in tc) {
                    if (!isClickClose)
                        isClickClose = closeButton.IsPixelClick(touchLocation.Position.X, touchLocation.Position.Y);
                }

                TouchLocation tL = base.currentState.GetTouchLocation();
                if (tL.State == TouchLocationState.Released)
                {
                    //關閉按鈕
                    if (closeButton.IsPixelClick(tL.Position.X, tL.Position.Y))
                    {
                        base.CloseDialog();//透過父類別來關閉
                    }
                }

                //清除TouchQueue裡的觸控點，因為避免Dequeue時候並不在Dialog中，因此要清除TouchQueue。
                base.currentState.ClearTouchQueue();
            }

            base.Update(); //更新遊戲元件
        }
        public override void Draw()
        {
            gameSateSpriteBatch.Draw(background, backgroundPos, Color.White);
            gameSateSpriteBatch.DrawString(topSavedPeopleNumberFont, topSavedPeoepleNumber.ToString(), new Vector2(background.Width / 2, background.Height / 2 - topSavedPeopleNumberFont.MeasureString(topSavedPeoepleNumber.ToString()).Y / 2), Color.Black);
            base.Draw(); //繪製遊戲元件
        }

        public void Readcored()
        {
            
            readData = StorageHelper.DeSerialize("record.catcher"); //無資料回傳null

            if (readData != null)
            {
                topSavedPeoepleNumber = readData.HistoryTopSavedNumber.ToString() + "\nPeople";
                    
            }
                
          
        }

    }
}
